"""
midi_importer.py - Enhanced MIDI importer with tempo detection
"""

from mido import MidiFile
import math
from tracker_core import Song, Pattern, ChannelData, midi_to_note

def import_midi(path: str,
                target_speed: int = 6,
                max_tracker_channels: int = 16,
                rows_per_pattern: int = 64) -> Song:
    """
    Import a standard MIDI file into a Song instance with auto tempo detection.

    Arguments:
      - path: Path to the .mid file to import.
      - target_speed: Tracker 'speed' (ticks per row).
      - max_tracker_channels: Number of tracker channels to use (1..16).
      - rows_per_pattern: How many rows each tracker pattern has.

    Returns:
      A Song object whose `patterns` and `orders` are filled with imported note data.
    """

    mid = MidiFile(path)
    ticks_per_beat = mid.ticks_per_beat

    # Extract tempo from the MIDI file
    tempo = 500000  # Default tempo (120 BPM in microseconds per beat)
    for track in mid.tracks:
        for msg in track:
            if msg.type == 'set_tempo':
                tempo = msg.tempo
                break
        if tempo != 500000:
            break
    
    # Convert tempo to BPM
    target_bpm = int(60000000 / tempo)
    print(f"Detected tempo: {target_bpm} BPM")

    # Compute how many MIDI ticks correspond to one tracker row
    ticks_per_row = ticks_per_beat / target_speed

    # Collect all events
    events = []  # (absolute_row, midi_channel, midi_note, velocity, program)
    program_changes = {}  # Track program changes per channel

    for track in mid.tracks:
        abs_ticks = 0
        for msg in track:
            abs_ticks += msg.time
            
            if msg.type == 'program_change':
                program_changes[msg.channel] = msg.program
            
            elif msg.type == 'note_on' and msg.velocity > 0:
                midi_ch = msg.channel
                if midi_ch < max_tracker_channels:
                    row_idx = int(abs_ticks / ticks_per_row)
                    current_program = program_changes.get(midi_ch, 0)
                    events.append((row_idx, midi_ch, msg.note, msg.velocity, current_program))

    # Determine the maximum row index
    max_row = max((r for (r, _, _, _, _) in events), default=0)

    # How many patterns we need
    num_patterns = math.ceil((max_row + 1) / rows_per_pattern)

    # Create a blank Song
    song = Song()
    song.initial_tempo = target_bpm
    song.initial_speed = target_speed

    # Build patterns
    song.patterns = [
        Pattern(num_rows=rows_per_pattern, num_channels=max_tracker_channels)
        for _ in range(num_patterns)
    ]

    # Build the order list
    song.orders = list(range(num_patterns))

    # Place each event into the appropriate pattern/row/cell
    for (abs_row, midi_ch, midi_note, velocity, program) in events:
        pat_index = abs_row // rows_per_pattern
        row_in_pat = abs_row % rows_per_pattern
        if pat_index >= len(song.patterns):
            continue

        cell: ChannelData = song.patterns[pat_index].rows[row_in_pat][midi_ch]
        cell.note = midi_to_note(midi_note)
        cell.instr = program + 1  # Tracker instruments are 1-based
        cell.vol = int((velocity / 127.0) * 64)
        cell.fx = ""
        cell.fxparam = 0

    return song