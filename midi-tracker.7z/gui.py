# gui.py — PySide6 GUI for the tracker clone with pattern tracking.

import sys
import os
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QTableWidget, QTableWidgetItem,
    QListWidget, QLabel, QPushButton, QSpinBox, QToolBar,
    QWidget, QHBoxLayout, QVBoxLayout, QComboBox, QFileDialog,
    QMessageBox, QSplitter, QGroupBox, QDockWidget, QSizePolicy
)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QFontDatabase

from tracker_core import Song, ChannelData, note_to_midi, load_soundfont, find_soundfonts, loaded_sf2_path
from midi import MidiInterface
from engine import Sequencer

class MainWindow(QMainWindow):
    def __init__(self, song: Song = None):
        super().__init__()
        self.setWindowTitle("Schism Tracker Clone (Python) - SoundFont Enhanced")
        self.setGeometry(100, 100, 1400, 800)  # Larger default size

        # === Core objects ===
        self.song = song or Song()
        self.midi = MidiInterface()
        self.sequencer = Sequencer(self.song, self.midi)
        
        # Track current pattern index
        self.current_pattern_idx = 0

        # === Pattern Editor Table ===
        self.pattern = self.song.patterns[0]
        self.num_channels = self.pattern.num_channels
        self.num_rows = self.pattern.num_rows

        # Table has 1 column for Row + 4 columns per channel (Note, Instr, Vol, Fx)
        total_cols = 1 + self.num_channels * 4
        self.table = QTableWidget(self.num_rows, total_cols)
        
        # Use monospace font for better alignment
        font = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        font.setPointSize(10)
        self.table.setFont(font)
        
        # Adjust column widths for better visibility
        self.table.setColumnWidth(0, 50)  # Row number
        for ch in range(self.num_channels):
            base = 1 + ch * 4
            self.table.setColumnWidth(base, 60)      # Note
            self.table.setColumnWidth(base + 1, 50)  # Instr
            self.table.setColumnWidth(base + 2, 50)  # Vol
            self.table.setColumnWidth(base + 3, 60)  # Fx

        # Set up column headers
        headers = ["Row"]
        for ch in range(self.num_channels):
            headers += [
                f"Ch{ch+1} Note",
                f"Ch{ch+1} Instr",
                f"Ch{ch+1} Vol",
                f"Ch{ch+1} Fx"
            ]
        self.table.setHorizontalHeaderLabels(headers)

        # Populate table with initial pattern data
        self._populate_table()

        # Connect editing signal
        self.table.itemChanged.connect(self.on_pattern_item_changed)

        # === Create Dock Widgets for side panels ===
        
        # Instrument Dock
        self.instrDock = QDockWidget("Instruments", self)
        self.instrDock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        instrWidget = QWidget()
        instrLayout = QVBoxLayout()
        
        # Instrument selector combo box
        self.instrCombo = QComboBox()
        self.refresh_instrument_combo()
        self.instrCombo.currentIndexChanged.connect(self.on_instrument_selected)
        instrLayout.addWidget(QLabel("Quick Select:"))
        instrLayout.addWidget(self.instrCombo)
        
        # Instrument list
        self.instrList = QListWidget()
        self.refresh_instrument_list()
        self.instrList.itemClicked.connect(self.on_instrument_list_clicked)
        instrLayout.addWidget(self.instrList)
        
        instrWidget.setLayout(instrLayout)
        self.instrDock.setWidget(instrWidget)
        self.addDockWidget(Qt.RightDockWidgetArea, self.instrDock)

        # Pattern/Order Dock
        self.orderDock = QDockWidget("Order List", self)
        self.orderDock.setAllowedAreas(Qt.LeftDockWidgetArea | Qt.RightDockWidgetArea)
        
        orderWidget = QWidget()
        orderLayout = QVBoxLayout()
        
        # Pattern selector combo
        self.patternCombo = QComboBox()
        for i in range(len(self.song.patterns)):
            self.patternCombo.addItem(f"Pattern {i}")
        self.patternCombo.currentIndexChanged.connect(self.on_pattern_selected)
        orderLayout.addWidget(QLabel("Edit Pattern:"))
        orderLayout.addWidget(self.patternCombo)
        
        # Order list
        self.orderList = QListWidget()
        for p in self.song.orders:
            self.orderList.addItem(f"Pattern {p}")
        self.orderList.itemClicked.connect(self.on_order_clicked)
        orderLayout.addWidget(QLabel("Play Order:"))
        orderLayout.addWidget(self.orderList)
        
        orderWidget.setLayout(orderLayout)
        self.orderDock.setWidget(orderWidget)
        self.addDockWidget(Qt.RightDockWidgetArea, self.orderDock)

        # === SoundFont Selector (in toolbar) ===
        self.sfCombo = QComboBox()
        self.sfCombo.setMinimumWidth(200)
        self.sfButton = QPushButton("Load SF2")
        self.sfButton.clicked.connect(self.load_soundfont_dialog)
        
        # Populate with found SoundFonts
        sf_files = find_soundfonts()
        self.sfCombo.addItem("Default GM")
        for sf in sf_files:
            self.sfCombo.addItem(os.path.basename(sf), sf)
        
        if loaded_sf2_path:
            # Select the loaded SoundFont
            for i in range(self.sfCombo.count()):
                if self.sfCombo.itemData(i) == loaded_sf2_path:
                    self.sfCombo.setCurrentIndex(i)
                    break
        
        self.sfCombo.currentIndexChanged.connect(self.on_soundfont_changed)

        # === Playback Controls ===
        self.playButton = QPushButton("▶ Play")
        self.stopButton = QPushButton("■ Stop")
        self.playButton.setMinimumWidth(80)
        self.stopButton.setMinimumWidth(80)
        
        self.tempoSpin = QSpinBox()
        self.tempoSpin.setRange(32, 300)
        self.tempoSpin.setValue(self.song.initial_tempo)
        self.tempoSpin.setMinimumWidth(60)
        
        self.speedSpin = QSpinBox()
        self.speedSpin.setRange(1, 32)
        self.speedSpin.setValue(self.song.initial_speed)
        self.speedSpin.setMinimumWidth(60)

        # Wire up signals
        self.playButton.clicked.connect(self.start_playback)
        self.stopButton.clicked.connect(self.on_stop_clicked)
        self.tempoSpin.valueChanged.connect(self.on_tempo_change)
        self.speedSpin.valueChanged.connect(self.on_speed_change)
        
        # Connect sequencer signals
        self.sequencer.rowChanged.connect(self.on_row_changed)
        self.sequencer.patternChanged.connect(self.on_pattern_changed_during_playback)

        # Create toolbar
        control_toolbar = QToolBar()
        control_toolbar.setMovable(False)
        control_toolbar.addWidget(self.playButton)
        control_toolbar.addWidget(self.stopButton)
        control_toolbar.addSeparator()
        control_toolbar.addWidget(QLabel("Tempo:"))
        control_toolbar.addWidget(self.tempoSpin)
        control_toolbar.addWidget(QLabel("Speed:"))
        control_toolbar.addWidget(self.speedSpin)
        control_toolbar.addSeparator()
        control_toolbar.addWidget(QLabel("SoundFont:"))
        control_toolbar.addWidget(self.sfCombo)
        control_toolbar.addWidget(self.sfButton)
        self.addToolBar(control_toolbar)

        # === View Menu ===
        viewMenu = self.menuBar().addMenu("View")
        viewMenu.addAction(self.instrDock.toggleViewAction())
        viewMenu.addAction(self.orderDock.toggleViewAction())
        
        # === Set the pattern table as central widget ===
        self.setCentralWidget(self.table)
        
        # === Status bar ===
        self.statusBar().showMessage("Ready")

    def refresh_instrument_combo(self):
        """Refresh the instrument combo box."""
        self.instrCombo.clear()
        for i, inst in enumerate(self.song.instruments):
            self.instrCombo.addItem(f"{i+1}: {inst.name}")

    def refresh_instrument_list(self):
        """Refresh the instrument list from the current Song."""
        self.instrList.clear()
        for i, inst in enumerate(self.song.instruments):
            self.instrList.addItem(f"{i+1:3d}: {inst.name}")

    def on_instrument_selected(self, index):
        """Handle instrument selection from combo box."""
        if index >= 0:
            self.instrList.setCurrentRow(index)

    def on_instrument_list_clicked(self, item):
        """Handle instrument selection from list."""
        row = self.instrList.row(item)
        self.instrCombo.setCurrentIndex(row)

    def on_pattern_selected(self, index):
        """Switch to editing a different pattern."""
        if 0 <= index < len(self.song.patterns):
            self.current_pattern_idx = index
            self.pattern = self.song.patterns[index]
            self.num_channels = self.pattern.num_channels
            self.num_rows = self.pattern.num_rows
            self._populate_table()
            self.statusBar().showMessage(f"Editing Pattern {index}")

    def on_order_clicked(self, item):
        """When clicking on order list, switch to that pattern for editing."""
        order_idx = self.orderList.row(item)
        if 0 <= order_idx < len(self.song.orders):
            pattern_idx = self.song.orders[order_idx]
            self.patternCombo.setCurrentIndex(pattern_idx)

    def on_pattern_changed_during_playback(self, order_idx):
        """Called when the sequencer advances to a new pattern."""
        if 0 <= order_idx < len(self.song.orders):
            # Highlight the current order in the order list
            self.orderList.setCurrentRow(order_idx)
            
            # Get the pattern index from the order
            pattern_idx = self.song.orders[order_idx]
            
            # Switch to viewing this pattern
            if pattern_idx != self.current_pattern_idx:
                self.patternCombo.setCurrentIndex(pattern_idx)
                
            self.statusBar().showMessage(f"Playing Order {order_idx} (Pattern {pattern_idx})")

    def on_stop_clicked(self):
        """Handle stop button click."""
        self.sequencer.stop()
        self.statusBar().showMessage("Stopped")
        # Clear row selection
        self.table.clearSelection()

    def load_soundfont_dialog(self):
        """Open a file dialog to load a SoundFont."""
        filename, _ = QFileDialog.getOpenFileName(
            self, "Load SoundFont", "", "SoundFont Files (*.sf2 *.SF2)"
        )
        if filename:
            if load_soundfont(filename):
                # Refresh the instrument list
                self.song.instruments.clear()
                from tracker_core import gm_names
                for prog, name in enumerate(gm_names):
                    self.song.instruments.append(type(self.song.instruments[0])(prog, name))
                self.refresh_instrument_list()
                self.refresh_instrument_combo()
                
                # Add to combo if not already there
                found = False
                for i in range(self.sfCombo.count()):
                    if self.sfCombo.itemData(i) == filename:
                        self.sfCombo.setCurrentIndex(i)
                        found = True
                        break
                
                if not found:
                    self.sfCombo.addItem(os.path.basename(filename), filename)
                    self.sfCombo.setCurrentIndex(self.sfCombo.count() - 1)
                
                QMessageBox.information(self, "Success", 
                    f"Loaded SoundFont: {os.path.basename(filename)}")
            else:
                QMessageBox.warning(self, "Error", 
                    f"Failed to load SoundFont: {filename}")

    def on_soundfont_changed(self, index):
        """Handle SoundFont selection change."""
        if index == 0:
            # Default GM
            from tracker_core import _default_gm
            self.song.instruments.clear()
            for prog, name in enumerate(_default_gm):
                self.song.instruments.append(type(self.song.instruments[0])(prog, name))
        else:
            sf_path = self.sfCombo.itemData(index)
            if sf_path and load_soundfont(sf_path):
                self.song.instruments.clear()
                from tracker_core import gm_names
                for prog, name in enumerate(gm_names):
                    self.song.instruments.append(type(self.song.instruments[0])(prog, name))
        
        self.refresh_instrument_list()
        self.refresh_instrument_combo()

    def _populate_table(self):
        """Fill the pattern table from Song data (block signals while doing it)."""
        self.table.blockSignals(True)
        
        # Adjust table size if needed
        if self.table.rowCount() != self.num_rows:
            self.table.setRowCount(self.num_rows)
        
        expected_cols = 1 + self.num_channels * 4
        if self.table.columnCount() != expected_cols:
            self.table.setColumnCount(expected_cols)
            
            # Reset headers
            headers = ["Row"]
            for ch in range(self.num_channels):
                headers += [
                    f"Ch{ch+1} Note",
                    f"Ch{ch+1} Instr", 
                    f"Ch{ch+1} Vol",
                    f"Ch{ch+1} Fx"
                ]
            self.table.setHorizontalHeaderLabels(headers)
        
        for r in range(self.num_rows):
            # Row number column
            item = QTableWidgetItem(f"{r:03d}")
            item.setFlags(Qt.ItemIsSelectable | Qt.ItemIsEnabled)
            item.setTextAlignment(Qt.AlignCenter)
            self.table.setItem(r, 0, item)

            # Per‐channel cells
            for ch in range(self.num_channels):
                cell = self.pattern.rows[r][ch]

                # Note
                note_item = QTableWidgetItem(cell.note or "")
                note_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, 1 + ch * 4, note_item)

                # Instr
                instr_txt = str(cell.instr) if cell.instr else ""
                instr_item = QTableWidgetItem(instr_txt)
                instr_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, 2 + ch * 4, instr_item)

                # Volume
                vol_txt = str(cell.vol) if cell.vol else ""
                vol_item = QTableWidgetItem(vol_txt)
                vol_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, 3 + ch * 4, vol_item)

                # Effect
                fx_txt = f"{cell.fx}{cell.fxparam:02X}" if cell.fx else ""
                fx_item = QTableWidgetItem(fx_txt)
                fx_item.setTextAlignment(Qt.AlignCenter)
                self.table.setItem(r, 4 + ch * 4, fx_item)

        self.table.blockSignals(False)

    def on_pattern_item_changed(self, item: QTableWidgetItem):
        """When the user edits the table, update the underlying Song data."""
        row, col = item.row(), item.column()
        if col == 0:
            return  # Row number is not editable

        chan  = (col - 1) // 4
        field = (col - 1) % 4
        text  = item.text().strip().upper()
        cell  = self.pattern.rows[row][chan]

        if field == 0:
            # Note column: allow OFF/---/empty → explicit note_off
            if text in ("OFF", "---", ""):
                cell.note = "--"
                cell.note_off = True
            else:
                cell.note = text
                cell.note_off = False

        elif field == 1:
            # Instrument
            try:
                cell.instr = int(text)
            except ValueError:
                cell.instr = 0

        elif field == 2:
            # Volume (0–64)
            try:
                v = int(text)
            except ValueError:
                v = 0
            cell.vol = max(0, min(64, v))

        elif field == 3:
            # Effect (e.g. "C04")
            if not text:
                cell.fx = ""
                cell.fxparam = 0
            else:
                cell.fx = text[0]
                try:
                    cell.fxparam = int(text[1:], 16)
                except ValueError:
                    cell.fxparam = 0

    def start_playback(self):
        """Sync UI tempo/speed into the Sequencer and start."""
        self.song.initial_tempo = self.tempoSpin.value()
        self.song.initial_speed = self.speedSpin.value()
        self.sequencer.tempo = self.song.initial_tempo
        self.sequencer.speed = self.song.initial_speed
        self.sequencer.update_timer_interval()
        self.sequencer.start()
        self.statusBar().showMessage("Playing...")

    def on_tempo_change(self, value: int):
        self.sequencer.set_tempo(value)

    def on_speed_change(self, value: int):
        self.sequencer.set_speed(value)

    def on_row_changed(self, row: int):
        """Highlight and scroll to the current row."""
        self.table.clearSelection()
        self.table.selectRow(row)
        self.table.scrollToItem(self.table.item(row, 0))
        
        # Update status with current position
        order_idx = self.sequencer.order_idx
        self.statusBar().showMessage(f"Playing Order {order_idx} - Row {row}/{self.num_rows}")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())