"""
midi.py - MIDI output interface using mido for the Schism Tracker clone.
"""
import mido

class MidiInterface:
    """
    MIDI output interface to send messages to the synth.
    """
    def __init__(self):
        # Try to open the Microsoft GS Wavetable Synth if available
        self.port = None
        self.current_bank = [0] * 16  # Track bank per channel
        
        for name in mido.get_output_names():
            if "GS Wavetable" in name or "Microsoft GS" in name:
                self.port = mido.open_output(name)
                print(f"Using MIDI output: {name}")
                break
        
        if self.port is None:
            # Fallback to default output
            try:
                self.port = mido.open_output()
                print(f"Using default MIDI output")
            except:
                print("Warning: No MIDI output available!")
                self.port = None

    def send_note_on(self, channel, note, velocity=100):
        """Send Note On message (channel 0-15, note 0-127, velocity 0-127)."""
        if self.port is None or note is None:
            return
        msg = mido.Message('note_on', channel=channel, note=note, velocity=velocity)
        self.port.send(msg)

    def send_note_off(self, channel, note, velocity=0):
        """Send Note Off message."""
        if self.port is None or note is None:
            return
        msg = mido.Message('note_off', channel=channel, note=note, velocity=velocity)
        self.port.send(msg)

    def set_bank(self, channel, bank):
        """Set bank for the given channel (for SoundFont support)."""
        if self.port is None:
            return
        # Bank Select MSB (CC 0)
        msg = mido.Message('control_change', channel=channel, control=0, value=bank >> 7)
        self.port.send(msg)
        # Bank Select LSB (CC 32)
        msg = mido.Message('control_change', channel=channel, control=32, value=bank & 0x7F)
        self.port.send(msg)
        self.current_bank[channel] = bank

    def set_program(self, channel, program, bank=0):
        """Send Program Change (instrument) on the given MIDI channel."""
        if self.port is None:
            return
        if bank != self.current_bank[channel]:
            self.set_bank(channel, bank)
        msg = mido.Message('program_change', channel=channel, program=program)
        self.port.send(msg)

    def set_channel_volume(self, channel, volume):
        """Set channel volume via CC7 (0-127)."""
        if self.port is None:
            return
        msg = mido.Message('control_change', channel=channel, control=7, value=volume)
        self.port.send(msg)

    def set_pan(self, channel, pan):
        """Set channel pan via CC10 (0-127)."""
        if self.port is None:
            return
        msg = mido.Message('control_change', channel=channel, control=10, value=pan)
        self.port.send(msg)

    def set_pitch_bend(self, channel, bend):
        """Set pitch bend (MIDI pitchwheel). Input bend is centered at 0: -8192 .. +8191."""
        if self.port is None:
            return
        msg = mido.Message('pitchwheel', channel=channel, pitch=bend)
        self.port.send(msg)

    def reset_all_controllers(self, channel):
        """Reset all controllers on a channel."""
        if self.port is None:
            return
        msg = mido.Message('control_change', channel=channel, control=121, value=0)
        self.port.send(msg)