# run_with_midi_import.py — Demo runner that uses midi_importer to load a .mid file
# and launch the GUI with enhanced features.

import sys
import os
import traceback
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import QTimer
from midi_importer import import_midi
from gui import MainWindow
from tracker_core import load_soundfont, find_soundfonts

def print_pattern_info(song):
    """Print detailed information about the imported patterns."""
    print("\n=== Pattern Information ===")
    for i, pat in enumerate(song.patterns):
        nonempty = 0
        instruments_used = set()
        notes_used = set()
        
        for row in pat.rows:
            for cell in row:
                if cell.note_off or (cell.note and cell.note != "--"):
                    nonempty += 1
                    if cell.note and cell.note != "--":
                        notes_used.add(cell.note)
                    if cell.instr > 0:
                        instruments_used.add(cell.instr)
        
        if nonempty > 0:
            print(f"\nPattern {i}:")
            print(f"  - Non-empty cells: {nonempty}")
            print(f"  - Instruments used: {sorted(instruments_used)}")
            print(f"  - Note range: {min(notes_used) if notes_used else 'N/A'} to {max(notes_used) if notes_used else 'N/A'}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python run_with_midi_import.py <path_to_midi_file.mid> [options]")
        print("\nOptions:")
        print("  --speed N        Set tracker speed (default: 6)")
        print("  --channels N     Max channels to use (default: 16)")
        print("  --rows N         Rows per pattern (default: 64)")
        print("  --soundfont PATH Use specific SoundFont file")
        print("  --no-autoplay    Don't start playback automatically")
        sys.exit(1)

    midi_path = sys.argv[1]
    
    # Parse command line options
    target_speed = 6
    max_channels = 16
    rows_per_pattern = 64
    soundfont_path = None
    autoplay = True
    
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == "--speed" and i + 1 < len(sys.argv):
            target_speed = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == "--channels" and i + 1 < len(sys.argv):
            max_channels = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == "--rows" and i + 1 < len(sys.argv):
            rows_per_pattern = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == "--soundfont" and i + 1 < len(sys.argv):
            soundfont_path = sys.argv[i + 1]
            i += 2
        elif sys.argv[i] == "--no-autoplay":
            autoplay = False
            i += 1
        else:
            print(f"Unknown option: {sys.argv[i]}")
            i += 1

    print(f"\n=== MIDI Import Settings ===")
    print(f"MIDI file: {midi_path}")
    print(f"Target speed: {target_speed} ticks/row")
    print(f"Max channels: {max_channels}")
    print(f"Rows per pattern: {rows_per_pattern}")
    
    # Load SoundFont if specified
    if soundfont_path:
        print(f"\nLoading SoundFont: {soundfont_path}")
        if not load_soundfont(soundfont_path):
            print("Warning: Failed to load specified SoundFont, using default")
    else:
        # Try to auto-detect a SoundFont
        sf_files = find_soundfonts()
        if sf_files:
            print(f"\nAuto-detected {len(sf_files)} SoundFont(s)")
            print(f"Using: {os.path.basename(sf_files[0])}")

    # Import the MIDI file
    try:
        print(f"\nImporting MIDI file...")
        song = import_midi(
            path=midi_path,
            target_speed=target_speed,
            max_tracker_channels=max_channels,
            rows_per_pattern=rows_per_pattern
        )
    except Exception:
        print("\nError during MIDI import:")
        traceback.print_exc()
        sys.exit(1)

    # Print summary
    n_patterns = len(song.patterns)
    total_rows = sum(p.num_rows for p in song.patterns)
    print(f"\n=== Import Summary ===")
    print(f"Patterns created: {n_patterns}")
    print(f"Total rows: {total_rows}")
    print(f"Initial tempo: {song.initial_tempo} BPM")
    print(f"Initial speed: {song.initial_speed} ticks/row")
    
    # Print detailed pattern info
    print_pattern_info(song)

    # Launch the Qt app
    print("\n=== Launching GUI ===")
    app = QApplication(sys.argv)
    window = MainWindow(song)
    window.setWindowTitle(f"Schism Tracker Clone - {os.path.basename(midi_path)}")
    window.show()

    # Auto-start playback if requested
    if autoplay:
        print("Auto-starting playback in 500ms...")
        QTimer.singleShot(500, window.start_playback)

    # Enter Qt main loop
    sys.exit(app.exec())

if __name__ == "__main__":
    main()