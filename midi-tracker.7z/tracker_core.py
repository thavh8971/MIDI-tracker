# tracker_core.py — Core data structures and utilities for the Python tracker clone.

import os
import glob

# -------------------------------------------------------------------
# 1) NOTE ↔ MIDI conversion map
# -------------------------------------------------------------------
NOTE_NAME_MAP = {
    "C-": 0,  "C#": 1, "D-": 2,  "D#": 3, "E-": 4,
    "F-": 5,  "F#": 6, "G-": 7,  "G#": 8, "A-": 9,
    "A#": 10, "B-": 11
}

def note_to_midi(note_str: str):
    """
    Convert tracker note string (e.g. "C-4", "A#3", "--") → MIDI note (0–127).
    Returns None if invalid or represents "no note".
    """
    s = (note_str or "").strip().upper()
    if not s or s == "--" or len(s) != 3:
        return None
    name, oc = s[:2], s[2]
    if name not in NOTE_NAME_MAP:
        return None
    try:
        octave = int(oc)
    except ValueError:
        return None
    num = 12 * (octave + 1) + NOTE_NAME_MAP[name]
    return num if 0 <= num <= 127 else None

def midi_to_note(midi_note: int) -> str:
    """
    Convert MIDI note (0–127) → tracker note string ("C-4", etc.).
    Returns "--" if out of range or None.
    """
    if midi_note is None or not (0 <= midi_note <= 127):
        return "--"
    octave   = midi_note // 12 - 1
    semitone = midi_note % 12
    inv_map  = {v: k for k, v in NOTE_NAME_MAP.items()}
    name     = inv_map.get(semitone, "--")
    return f"{name}{octave}"

# -------------------------------------------------------------------
# 2) Enhanced SoundFont loading with multiple search paths
# -------------------------------------------------------------------
def find_soundfonts():
    """Find all available SoundFont files in common locations."""
    search_paths = [
        os.path.dirname(__file__),  # Current directory
        os.path.expanduser("~/Documents"),  # User documents
        os.path.expanduser("~/Music"),  # User music folder
        "C:/Windows/System32",  # Windows system folder
        "C:/Windows/SysWOW64",  # Windows 64-bit system folder
        "/usr/share/sounds/sf2",  # Linux common location
        "/usr/local/share/sounds/sf2",  # Linux local
    ]
    
    sf2_files = []
    for path in search_paths:
        if os.path.exists(path):
            sf2_files.extend(glob.glob(os.path.join(path, "*.sf2")))
            sf2_files.extend(glob.glob(os.path.join(path, "*.SF2")))
    
    return list(set(sf2_files))  # Remove duplicates

# Default GM names (128 items)
_default_gm = [
    "Acoustic Grand", "Bright Acoustic", "Electric Grand", "Honky-Tonk",
    "Electric Piano 1", "Electric Piano 2", "Harpsichord", "Clavinet",
    "Celesta", "Glockenspiel", "Music Box", "Vibraphone", "Marimba",
    "Xylophone", "Tubular Bells", "Dulcimer", "Drawbar Organ",
    "Percussive Organ", "Rock Organ", "Church Organ", "Reed Organ",
    "Accordion", "Harmonica", "Tango Accordion", "Nylon String Guitar",
    "Steel String Guitar", "Electric Jazz Guitar", "Electric Clean Guitar",
    "Electric Muted Guitar", "Overdriven Guitar", "Distortion Guitar",
    "Guitar Harmonics", "Acoustic Bass", "Electric Bass (finger)",
    "Electric Bass (pick)", "Fretless Bass", "Slap Bass 1", "Slap Bass 2",
    "Synth Bass 1", "Synth Bass 2", "Violin", "Viola", "Cello", "Contrabass",
    "Tremolo Strings", "Pizzicato Strings", "Orchestral Strings",
    "Timpani", "String Ensemble 1", "String Ensemble 2", "SynthStrings 1",
    "SynthStrings 2", "Choir Aahs", "Voice Oohs", "Synth Voice",
    "Orchestra Hit", "Trumpet", "Trombone", "Tuba", "Muted Trumpet",
    "French Horn", "Brass Section", "SynthBrass 1", "SynthBrass 2",
    "Soprano Sax", "Alto Sax", "Tenor Sax", "Baritone Sax", "Oboe",
    "English Horn", "Bassoon", "Clarinet", "Piccolo", "Flute", "Recorder",
    "Pan Flute", "Blown Bottle", "Shakuhachi", "Whistle", "Ocarina",
    "Square Wave", "Saw Wave", "Synth Calliope", "Chiffer Lead",
    "Charang", "Solo Vox", "5th Saw Wave", "Bass & Lead", "Fantasia",
    "Warm Pad", "Polysynth", "Space Voice", "Bowed Glass", "Metal Pad",
    "Halo Pad", "Sweep Pad", "Ice Rain", "Soundtrack", "Crystal",
    "Atmosphere", "Brightness", "Goblin", "Echo Drops", "Star Theme",
    "Sitar", "Banjo", "Shamisen", "Koto", "Kalimba", "Bagpipe",
    "Fiddle", "Shanai", "Tinkle Bell", "Agogo", "Steel Drums",
    "Woodblock", "Taiko Drum", "Melodic Tom", "Synth Drum",
    "Reverse Cymbal", "Guitar Fret Noise", "Breath Noise", "Seashore",
    "Bird Tweet", "Telephone Ring", "Helicopter", "Applause", "Gunshot"
]

# Global variables for SoundFont data
gm_names = _default_gm.copy()
loaded_sf2_path = None
sf2_presets = {}

def load_soundfont(sf2_path=None):
    """Load a specific SoundFont file or auto-detect one."""
    global gm_names, loaded_sf2_path, sf2_presets
    
    if sf2_path is None:
        sf2_files = find_soundfonts()
        if not sf2_files:
            print("No SoundFont files found, using default GM names.")
            return False
        sf2_path = sf2_files[0]  # Use the first found
        print(f"Auto-detected SoundFont: {sf2_path}")
    
    try:
        from sf2utils.sf2parse import Sf2File
        with open(sf2_path, "rb") as f:
            sf2 = Sf2File(f)
        
        # Extract all presets
        sf2_presets.clear()
        for preset in sf2.presets:
            if hasattr(preset, 'bank') and hasattr(preset, 'preset'):
                key = (preset.bank, preset.preset)
                sf2_presets[key] = preset
        
        # Update GM names from bank 0
        bank0_presets = [(p.preset, p) for p in sf2.presets if getattr(p, "bank", 0) == 0]
        bank0_presets.sort(key=lambda x: x[0])
        
        for prog, preset in bank0_presets[:128]:
            if prog < 128:
                gm_names[prog] = preset.name.strip()
        
        loaded_sf2_path = sf2_path
        print(f"Loaded SoundFont: {os.path.basename(sf2_path)} ({len(sf2_presets)} presets)")
        return True
        
    except ImportError:
        print("sf2utils not installed. Install with: pip install sf2utils")
        return False
    except Exception as e:
        print(f"Error loading SoundFont '{sf2_path}': {e}")
        return False

# Try to auto-load a SoundFont on module import
load_soundfont()

# -------------------------------------------------------------------
# 3) Core data classes
# -------------------------------------------------------------------
class ChannelData:
    """
    One channel's data in a pattern row.
      - note:      "C-4"/"A#3"/"--"
      - instr:     1–128 or 0
      - vol:       0–64
      - fx:        letter or ""
      - fxparam:   0–255
      - note_off:  explicit OFF flag set by the GUI
    """
    def __init__(self,
                 note: str    = "--",
                 instr: int   = 0,
                 vol: int     = 0,
                 fx: str      = "",
                 fxparam: int = 0):
        self.note     = note
        self.instr    = instr
        self.vol      = vol
        self.fx       = fx
        self.fxparam  = fxparam
        self.note_off = False

    def is_note_off(self) -> bool:
        return bool(self.note_off)

    def __repr__(self):
        return (f"<ChannelData note={self.note!r} off={self.note_off} "
                f"instr={self.instr} vol={self.vol} "
                f"fx={self.fx!r}{self.fxparam:02X}>")

class Pattern:
    """A grid of ChannelData: rows × channels."""
    def __init__(self, num_rows: int = 64, num_channels: int = 8):
        self.num_rows     = num_rows
        self.num_channels = num_channels
        self.rows = [
            [ChannelData() for _ in range(self.num_channels)]
            for _ in range(self.num_rows)
        ]

class Instrument:
    """General‐MIDI instrument (program 0–127, name)."""
    def __init__(self, program: int = 0, name: str = "", bank: int = 0):
        self.program = max(0, min(127, program))
        self.bank = bank
        self.name = name or gm_names[program]

class Song:
    """
    Complete song:
      - patterns:       List[Pattern]
      - orders:         List[int] (pattern indices)
      - instruments:    List[Instrument] (128 GM slots)
      - initial_tempo:  BPM
      - initial_speed:  ticks per row
    """
    def __init__(self):
        self.patterns      = []
        self.orders        = []
        self.instruments   = []
        self.initial_tempo = 125
        self.initial_speed = 6

        # Fill out the 128 GM instruments
        for prog, name in enumerate(gm_names):
            self.instruments.append(Instrument(prog, name))

        # Start with one empty pattern
        default_pat = Pattern()
        self.patterns.append(default_pat)
        self.orders.append(0)