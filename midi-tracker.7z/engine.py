# engine.py — Playback engine (sequencer) for the tracker clone using conventional MIDI timing.

import logging
from PySide6.QtCore import QObject, QTimer, Signal, Qt
from tracker_core import Song, note_to_midi
from midi import MidiInterface

log = logging.getLogger(__name__)
log.setLevel(logging.DEBUG)

def clamp7(x: int) -> int:
    """Clamp any integer to the MIDI 0–127 range."""
    return max(0, min(127, x))

class Sequencer(QObject):
    """
    Sequencer runs in real time, stepping through patterns and sending MIDI events.
    Now it uses a traditional MIDI timing method via a PPQ (pulses per quarter note) value.
    """
    rowChanged = Signal(int)      # Emitted when the current row changes (for UI updates)
    patternChanged = Signal(int)  # Emitted when pattern changes

    def __init__(self, song: Song, midi: MidiInterface):
        super().__init__()
        self.song = song
        self.midi = midi

        # Playback settings
        self.order_idx = 0
        self.row = 0
        self.tick = 0
        self.speed = song.initial_speed  # Number of ticks per row (tracker “speed”)
        self.tempo = song.initial_tempo  # BPM
        self.ppq = 24                    # Pulses per quarter note (conventional MIDI resolution)
        self.playing = False

        self.current_pattern = self.song.patterns[self.song.orders[0]]
        self.num_channels = self.current_pattern.num_channels

        # Per-channel state
        self.channel_program = [None] * self.num_channels
        self.channel_bank    = [0] * self.num_channels
        self.channel_note    = [None] * self.num_channels
        self.channel_vol     = [64] * self.num_channels
        self.volume_slides   = [None] * self.num_channels

        # Timer for stepping through ticks using conventional MIDI timing
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.step)
        self.timer.setTimerType(Qt.PreciseTimer)
        self.update_timer_interval()

    def update_timer_interval(self):
        """Update QTimer interval using the conventional MIDI tick duration formula."""
        if self.tempo > 0:
            # Calculate the duration of one MIDI tick (in ms)
            interval = 60000.0 / (self.tempo * self.ppq)
        else:
            interval = 20.0
        self.timer.setInterval(int(interval))
        log.debug(f"Timer interval set to {int(interval)} ms (BPM={self.tempo}, PPQ={self.ppq})")

    def set_tempo(self, tempo):
        """Set the tempo (BPM), update the timer interval, and log the change."""
        if tempo > 0:
            self.tempo = tempo
            self.update_timer_interval()
            log.debug(f"Tempo changed to {self.tempo} BPM")

    def set_speed(self, speed):
        """Set the playback speed (ticks per row). This value, multiplied by the MIDI tick interval,
           defines the duration of each row.
        """
        if speed > 0:
            self.speed = speed
            log.debug(f"Speed (ticks per row) changed to {self.speed}")

    def start(self):
        """Start playback from the beginning of the song."""
        log.info("=== Sequencer START ===")
        self.order_idx = 0
        self.row = 0
        self.tick = 0
        self.playing = True
        self.current_pattern = self.song.patterns[self.song.orders[0]]
        
        # Reset all MIDI channels
        for ch in range(16):
            self.midi.reset_all_controllers(ch)
        
        self.timer.start()
        self.patternChanged.emit(self.order_idx)

    def stop(self):
        """Stop playback and send Note Off for any active notes."""
        log.info("=== Sequencer STOP ===")
        self.playing = False
        self.timer.stop()
        
        # Send note off for all active notes
        for ch, note in enumerate(self.channel_note):
            if note is not None:
                self.midi.send_note_off(ch, note)
                log.debug(f" ch{ch}: note_off {note}")
                self.channel_note[ch] = None

    def step(self):
        """Advance the sequencer by one MIDI tick.
           A row is processed when tick == 0 and then every row lasts for 'speed' ticks.
        """
        if not self.playing:
            return
            
        log.debug(f"TICK → order={self.order_idx}, row={self.row}, tick={self.tick}/{self.speed}")

        # On the first tick of each row, process the row's events.
        if self.tick == 0:
            self.process_row()
        else:
            self.process_tick_effects()

        self.tick += 1
        
        # When the number of ticks equals the speed value, move to the next row.
        if self.tick >= self.speed:
            self.tick = 0
            self.row += 1
            if self.row >= self.current_pattern.num_rows:
                self.advance_pattern()

    def process_row(self):
        """Process the events for all channels in the current row."""
        row_data = self.current_pattern.rows[self.row]
        pattern_jump = False

        for ch in range(self.num_channels):
            if pattern_jump:
                break  # Skip remaining channels if a jump occurs
                
            cell = row_data[ch]
            midi_note = note_to_midi(cell.note)
            self.volume_slides[ch] = None

            if cell.note_off and self.channel_note[ch] is not None:
                self.midi.send_note_off(ch, self.channel_note[ch])
                log.debug(f" ch{ch}: explicit NOTE_OFF")
                self.channel_note[ch] = None

            elif midi_note is not None:
                if self.channel_note[ch] is not None:
                    self.midi.send_note_off(ch, self.channel_note[ch])
                    self.channel_note[ch] = None
                
                if cell.instr > 0:
                    instr = cell.instr - 1  # Convert to 0-based index
                    if instr < len(self.song.instruments):
                        instrument = self.song.instruments[instr]
                        if (self.channel_program[ch] != instrument.program or 
                            self.channel_bank[ch] != instrument.bank):
                            self.channel_program[ch] = instrument.program
                            self.channel_bank[ch] = instrument.bank
                            self.midi.set_program(ch, instrument.program, instrument.bank)
                            log.debug(f" ch{ch}: program_change → {instrument.program} (bank {instrument.bank})")

                if cell.vol > 0:
                    self.channel_vol[ch] = cell.vol
                    midi_vol = clamp7(int(cell.vol * 127 / 64))
                    self.midi.set_channel_volume(ch, midi_vol)
                    log.debug(f" ch{ch}: set_channel_volume → {midi_vol}")

                velocity = clamp7(int(self.channel_vol[ch] * 127 / 64))
                self.midi.send_note_on(ch, midi_note, velocity)
                log.debug(f" ch{ch}: note_on {midi_note} vel={velocity}")
                self.channel_note[ch] = midi_note

            fx = (cell.fx or "").upper()
            param = cell.fxparam or 0

            if fx == 'A' and param > 0:
                # Using effect 'A' to set speed (ticks per row).
                self.set_speed(param)

            elif fx == 'T' and param > 0:
                # Effect 'T' sets the tempo.
                self.set_tempo(param)

            elif fx == 'B' and 0 <= param < len(self.song.orders):
                log.debug(f" ch{ch}: Jump to order {param}")
                self.order_idx = param
                self.current_pattern = self.song.patterns[self.song.orders[self.order_idx]]
                self.row = 0
                self.tick = 0
                pattern_jump = True
                self.patternChanged.emit(self.order_idx)

            elif fx == 'C':
                log.debug(f" ch{ch}: Pattern break")
                pattern_jump = True

            elif fx == 'D':
                log.debug(f" ch{ch}: Vol slide param=0x{param:02X}")
                self.volume_slides[ch] = param

        self.rowChanged.emit(self.row)
        if pattern_jump and fx == 'C':
            self.advance_pattern()

    def process_tick_effects(self):
        """Process ongoing effects that occur on non-initial ticks (like volume slides)."""
        for ch in range(self.num_channels):
            slide = self.volume_slides[ch]
            if slide:
                up   = (slide >> 4) & 0xF
                down = slide & 0xF
                vol  = self.channel_vol[ch]
                if up > 0:
                    vol = min(64, vol + up)
                if down > 0:
                    vol = max(0, vol - down)
                if vol != self.channel_vol[ch]:
                    self.channel_vol[ch] = vol
                    midi_vol = clamp7(int(vol * 127 / 64))
                    self.midi.set_channel_volume(ch, midi_vol)
                    log.debug(f" ch{ch}: slide to volume {midi_vol}")

    def advance_pattern(self):
        """Advance to the next pattern in the song order."""
        self.order_idx += 1
        if self.order_idx >= len(self.song.orders):
            if hasattr(self.song, 'loop') and self.song.loop:
                self.order_idx = 0
            else:
                self.stop()
                return
        
        self.current_pattern = self.song.patterns[self.song.orders[self.order_idx]]
        self.row = 0
        self.tick = 0
        self.patternChanged.emit(self.order_idx)
